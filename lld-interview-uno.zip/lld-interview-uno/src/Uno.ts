import { DeckStrategy } from "./deck/DeckStrategy";

export class Uno {
    createGame(deckStrategy: DeckStrategy) {}
}
